const ASSET = (name) => chrome.runtime.getURL(`assets/${name}`);

let host;
let shadow;
let analyzing = false;
let manuallyHidden = false;
let currentPage;
let currentResult;

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "TLD_TOGGLE") return;
  const root = shadow?.querySelector(".tld-root");
  if (root) {
    const isHidden = root.classList.contains("tld-hidden");
    root.classList.toggle("tld-hidden", !isHidden);
    manuallyHidden = !isHidden;
    if (isHidden && currentResult && currentPage) {
      renderSummary(currentResult, currentPage);
    }
    return;
  }
  manuallyHidden = false;
  analyze(true);
});

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function applyTheme(theme) {
  const root = shadow?.querySelector(".tld-root");
  if (root) root.dataset.theme = theme === "light" || theme === "dark" ? theme : "system";
}

function ensureUi() {
  if (host) return;
  host = document.createElement("div");
  host.id = "tldretriever-host";
  shadow = host.attachShadow({ mode: "open" });
  const stylesheet = document.createElement("link");
  stylesheet.rel = "stylesheet";
  stylesheet.href = chrome.runtime.getURL("overlay.css");
  shadow.append(stylesheet);
  const root = document.createElement("div");
  root.className = "tld-root";
  root.dataset.theme = "system";
  shadow.append(root);
  document.documentElement.append(host);

  chrome.storage.sync.get("theme").then(({ theme }) => applyTheme(theme));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.theme) applyTheme(changes.theme.newValue);
  });
  shadow.addEventListener("click", (event) => {
    const close = event.target.closest("[data-close]");
    if (close) {
      manuallyHidden = true;
      root.classList.add("tld-hidden");
    }
    const jump = event.target.closest("[data-jump]");
    if (jump) document.getElementById(jump.dataset.jump)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  });
}

function render(message, summary = false) {
  const root = shadow.querySelector(".tld-root");
  root.classList.remove("tld-hidden");
  root.innerHTML = `
    <header class="tld-header">
      <strong class="tld-brand">WebHound</strong>
      <button class="tld-close" type="button" data-close aria-label="Close">
        <img src="${ASSET("close.svg")}" width="13" height="13" alt="">
      </button>
    </header>
    <main class="tld-body${summary ? " tld-ready" : ""}">${message}</main>
  `;
}

function extractPage() {
  const root =
    document.querySelector("article") ||
    document.querySelector("[role='main']") ||
    document.querySelector("main") ||
    document.body;
  const usedIds = new Set([...document.querySelectorAll("[id]")].map((element) => element.id));
  const headingIds = new Set();
  const headings = [...root.querySelectorAll("h1, h2, h3")].map((element, index) => {
    if (!element.id || headingIds.has(element.id)) {
      let nextId = `tld-section-${index}`;
      let suffix = 1;
      while (usedIds.has(nextId)) nextId = `tld-section-${index}-${suffix++}`;
      element.id = nextId;
    }
    usedIds.add(element.id);
    headingIds.add(element.id);
    return { id: element.id, text: element.innerText.trim().slice(0, 120) };
  }).filter((heading) => heading.text);
  const clone = root.cloneNode(true);
  clone.querySelectorAll("script, style, noscript, nav, footer, aside, iframe, svg, form")
    .forEach((element) => element.remove());
  const text = clone.innerText.replace(/\s+/g, " ").trim().slice(0, 9000);
  return {
    title: document.title || "Untitled page",
    headings,
    text,
  };
}

function summaryHtml(summary, validIds, deduplicateLocations = true) {
  const usedIds = new Set();
  return (Array.isArray(summary) ? summary : [])
    .filter((part) => {
      if (!part?.text || !part.headingId || !validIds.has(part.headingId)) {
        return false;
      }
      if (deduplicateLocations && usedIds.has(part.headingId)) return false;
      usedIds.add(part.headingId);
      return true;
    })
    .map((part) => {
      const jump = part.headingId ? ` data-jump="${escapeHtml(part.headingId)}"` : "";
      return `<button class="tld-summary-sentence"${jump}>${escapeHtml(part.text)}</button>`;
    })
    .join(" ");
}

function renderSummary(result, page) {
  const validIds = new Set(page.headings.map((heading) => heading.id));
  const points = (result.keyPoints || []).slice(0, 3).map((point) =>
    `<li><img src="${ASSET("status-dot.svg")}" width="5" height="5" alt="">${escapeHtml(point)}</li>`,
  ).join("");
  render(`
    <section class="tld-section">
      <h2>Summary</h2>
      <p class="tld-summary">${summaryHtml(result.summary, validIds)}</p>
    </section>
    ${points ? `
      <section class="tld-section">
        <h2>Key points</h2>
        <ul class="tld-points">${points}</ul>
      </section>` : ""}
  `, true);
}

async function analyze(force = false) {
  if (analyzing) return;
  manuallyHidden = false;
  const { autoShow = true } = await chrome.storage.sync.get("autoShow");
  if (!force && !autoShow) return;
  const page = extractPage();
  currentPage = page;
  if (page.text.length < 80) return;
  analyzing = true;
  ensureUi();
  render("<p class='tld-message'>Summarizing…</p>");
  try {
    const response = await chrome.runtime.sendMessage({
      type: "TLD_ANALYZE",
      payload: { page },
    });
    if (!response?.ok) throw new Error(response?.error || "Analysis failed");
    currentResult = response.result;
    if (!manuallyHidden) renderSummary(currentResult, page);
  } catch (error) {
    if (!manuallyHidden) render(`<p class="tld-message">${escapeHtml(error.message)}</p>`);
  } finally {
    analyzing = false;
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", analyze, { once: true });
} else {
  analyze();
}
