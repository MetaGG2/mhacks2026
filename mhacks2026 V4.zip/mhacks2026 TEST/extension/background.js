import { generateStructured } from "./lib/gemini.mjs";
import { providerForModel, resolveModel } from "./lib/models.mjs";
import { readingPrompt, readingSchema } from "./lib/schemas.mjs";

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "TLD_ANALYZE") return undefined;
  analyze(message.payload)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function analyze(payload) {
  const stored = await chrome.storage.sync.get(["geminiApiKey", "grokApiKey", "model"]);
  const model = resolveModel(stored.model);
  const provider = providerForModel(model);
  const apiKey = (provider === "grok" ? stored.grokApiKey : stored.geminiApiKey)?.trim();
  if (!apiKey) {
    throw new Error("Set your API key in Extensions --> More Options --> Options");
  }
  if (!/^[\x20-\x7E]+$/.test(apiKey)) {
    throw new Error("Your API key contains invalid characters. Paste the key again without quotes or spaces.");
  }
  return generateStructured({
    apiKey,
    model,
    prompt: readingPrompt(payload.page),
    schema: readingSchema,
    schemaName: "tld_reading",
  });
}

chrome.action.onClicked.addListener(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "TLD_TOGGLE" });
  } catch {
    // The content script is unavailable on restricted browser pages.
  }
});
