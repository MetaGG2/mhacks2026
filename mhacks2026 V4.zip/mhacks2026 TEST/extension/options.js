import {
  DEFAULT_MODEL,
  GEMINI_MODELS,
  GROK_MODELS,
  providerForModel,
  resolveModel,
} from "./lib/models.mjs";

const form = document.getElementById("options-form");
const themeSelect = document.getElementById("theme");
const autoShow = document.getElementById("auto-show");
const modelSelect = document.getElementById("model");
const geminiKey = document.getElementById("gemini-key");
const grokKey = document.getElementById("grok-key");
const note = document.getElementById("model-note");
const status = document.getElementById("status");

function optionGroup(label, models) {
  const group = document.createElement("optgroup");
  group.label = label;
  for (const id of models) {
    const option = document.createElement("option");
    option.value = id;
    option.textContent = id;
    group.append(option);
  }
  return group;
}

modelSelect.append(optionGroup("Google Gemini", GEMINI_MODELS));
modelSelect.append(optionGroup("xAI Grok", GROK_MODELS));

function applyPageTheme(theme) {
  document.documentElement.dataset.theme =
    theme === "light" || theme === "dark" ? theme : "system";
}

themeSelect.addEventListener("change", () => {
  applyPageTheme(themeSelect.value);
  status.textContent = "";
});

function syncProviderNote() {
  const provider = providerForModel(modelSelect.value);
  const usesGrok = provider === "grok";
  note.textContent = usesGrok
    ? "This model uses your Grok API key and calls api.x.ai."
    : "This model uses your Gemini API key and calls Google generateContent.";
}

modelSelect.addEventListener("change", () => {
  status.textContent = "";
  syncProviderNote();
});

const storage = globalThis.chrome?.storage?.sync;

if (storage) {
  storage
    .get(["geminiApiKey", "grokApiKey", "model", "theme", "autoShow"])
    .then(({ geminiApiKey, grokApiKey, model, theme, autoShow: savedAutoShow }) => {
      if (geminiApiKey) geminiKey.value = geminiApiKey;
      if (grokApiKey) grokKey.value = grokApiKey;
      modelSelect.value = resolveModel(model || DEFAULT_MODEL);
      themeSelect.value = theme === "light" || theme === "dark" ? theme : "system";
      autoShow.checked = savedAutoShow !== false;
      applyPageTheme(themeSelect.value);
      syncProviderNote();
    });
} else {
  modelSelect.value = DEFAULT_MODEL;
  themeSelect.value = "system";
  autoShow.checked = true;
  applyPageTheme("system");
  syncProviderNote();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const model = resolveModel(modelSelect.value);
  const theme = themeSelect.value === "light" || themeSelect.value === "dark" ? themeSelect.value : "system";
  applyPageTheme(theme);
  const settings = {
    model,
    theme,
    autoShow: autoShow.checked,
    geminiApiKey: geminiKey.value.trim(),
    grokApiKey: grokKey.value.trim(),
  };
  if (!storage) {
    status.textContent = "Open this page from the extension options to save.";
    return;
  }
  await storage.set(settings);
  const provider = providerForModel(model) === "grok" ? "Grok" : "Gemini";
  status.textContent = `Saved. Requests will use ${model} (${provider}).`;
});
