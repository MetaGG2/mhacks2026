# WebHound

Chrome extension that shows a compact reading summary and key points in the top-right of a page. Summary sentences link back to the source section.

Design: [Figma — Extension Popup](https://www.figma.com/design/ULgF2fFK4yfLpmjMiVQCWl/MHACKS-2026?node-id=18-3)

## Load the extension

1. Get a Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).
2. Chrome → `chrome://extensions` → enable Developer mode → **Load unpacked** → select the `extension/` folder.
3. Open the extension **Options** page and paste the API key.
4. Visit an article. The overlay should appear. On Google Search it switches to intent categories.

Click the toolbar icon to hide or show the panel.

## Layout

- `extension/` — Manifest V3 overlay and options page
- `extension/lib/` — provider clients, model catalog, and JSON schemas
- `docs/superpowers/` — design spec and implementation plan
