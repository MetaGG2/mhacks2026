const ASSET = (name) => chrome.runtime.getURL(`assets/${name}`);

let host;
let shadow;
let analyzing = false;
let manuallyHidden = false;
let currentPage;
let currentResult;
let dragState;
const MODEL_GROUPS = {
  Gemini: ["gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite"],
  Grok: ["grok-4.7", "grok-4.6", "grok-4.5", "grok-4.3", "grok-4.20-0309-non-reasoning", "grok-4.20-0309-reasoning"],
};
const DEFAULT_MODEL = "gemini-3.1-flash-lite";

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "TLD_TOGGLE") return;
  const root = shadow?.querySelector(".tld-root");
  if (root) {
    const isHidden = root.classList.contains("tld-hidden");
    root.classList.toggle("tld-hidden", !isHidden);
    manuallyHidden = !isHidden;
    if (isHidden && currentResult && currentPage) {
      renderSummary(currentResult, currentPage);
    }
    return;
  }
  manuallyHidden = false;
  analyze(true);
});

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function applyTheme(theme) {
  const root = shadow?.querySelector(".tld-root");
  if (root) root.dataset.theme = theme === "light" || theme === "dark" ? theme : "system";
}

function ensureUi() {
  if (host) return;
  host = document.createElement("div");
  host.id = "tldretriever-host";
  shadow = host.attachShadow({ mode: "open" });
  const stylesheet = document.createElement("link");
  stylesheet.rel = "stylesheet";
  stylesheet.href = chrome.runtime.getURL("overlay.css");
  shadow.append(stylesheet);
  const root = document.createElement("div");
  root.className = "tld-root";
  root.dataset.theme = "system";
  shadow.append(root);
  document.documentElement.append(host);

  chrome.storage.sync.get("theme").then(({ theme }) => applyTheme(theme));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    if (changes.theme) applyTheme(changes.theme.newValue);
    syncSettingsMenu(root);
  });
  shadow.addEventListener("click", (event) => {
    const refresh = event.target.closest("[data-refresh]");
    if (refresh) {
      analyze(true);
      return;
    }
    const settings = event.target.closest("[data-settings]");
    if (settings) {
      root.classList.toggle("tld-settings-open");
      return;
    }
    const close = event.target.closest("[data-close]");
    if (close) {
      manuallyHidden = true;
      root.classList.add("tld-hidden");
    }
    const jump = event.target.closest("[data-jump]");
    if (jump) document.getElementById(jump.dataset.jump)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  });
  shadow.addEventListener("pointerdown", startDrag);
  shadow.addEventListener("pointermove", moveDrag);
  shadow.addEventListener("pointerup", endDrag);
  shadow.addEventListener("pointercancel", endDrag);
  shadow.addEventListener("wheel", scrollOverlay, { passive: false });
  shadow.addEventListener("change", updateSetting);
}

function syncSettingsMenu(root) {
  chrome.storage.sync.get(["apiKey", "model", "autoShow", "theme"]).then(({ apiKey, model, autoShow, theme }) => {
    const modelSelect = root.querySelector("[data-model]");
    const autoShowInput = root.querySelector("[data-auto-show]");
    const apiKeyInput = root.querySelector("[data-api-key]");
    const themeSelect = root.querySelector("[data-theme]");
    if (apiKeyInput) apiKeyInput.value = apiKey || "";
    if (themeSelect) themeSelect.value = theme === "light" || theme === "dark" ? theme : "system";
    if (modelSelect) {
      const provider = apiKey?.startsWith("AIza") ? "Gemini" : apiKey?.startsWith("xai-") ? "Grok" : null;
      for (const group of modelSelect.querySelectorAll("optgroup")) {
        group.hidden = Boolean(provider && group.label !== provider);
      }
      const available = [...modelSelect.options].find((option) => !option.parentElement.hidden);
      const selected = [...modelSelect.options].find((option) => option.value === model && !option.parentElement.hidden);
      modelSelect.value = selected?.value || available?.value || DEFAULT_MODEL;
    }
    if (autoShowInput) autoShowInput.checked = autoShow !== false;
  });
}

function updateSetting(event) {
  const root = shadow?.querySelector(".tld-root");
  if (!root) return;
  const modelSelect = event.target.closest("[data-model]");
  const autoShowInput = event.target.closest("[data-auto-show]");
  const apiKeyInput = event.target.closest("[data-api-key]");
  const themeSelect = event.target.closest("[data-theme]");
  if (modelSelect) chrome.storage.sync.set({ model: modelSelect.value });
  if (autoShowInput) chrome.storage.sync.set({ autoShow: autoShowInput.checked });
  if (apiKeyInput) {
    chrome.storage.sync.set({ apiKey: apiKeyInput.value.trim() });
    syncSettingsMenu(root);
  }
  if (themeSelect) {
    const theme = themeSelect.value === "light" || themeSelect.value === "dark"
      ? themeSelect.value
      : "system";
    chrome.storage.sync.set({ theme });
    applyTheme(theme);
  }
}

function scrollOverlay(event) {
  const root = shadow?.querySelector(".tld-root");
  if (!root || !root.contains(event.target)) return;
  event.preventDefault();
  root.scrollTop += event.deltaY;
}

function startDrag(event) {
  const root = shadow?.querySelector(".tld-root");
  const header = event.target.closest(".tld-header");
  if (!root || !header || event.button !== 0 || event.target.closest("button")) return;
  const bounds = root.getBoundingClientRect();
  dragState = {
    pointerId: event.pointerId,
    offsetX: event.clientX - bounds.left,
    offsetY: event.clientY - bounds.top,
  };
  root.setPointerCapture(event.pointerId);
  root.classList.add("tld-dragging");
  event.preventDefault();
}

function moveDrag(event) {
  const root = shadow?.querySelector(".tld-root");
  if (!root || !dragState || event.pointerId !== dragState.pointerId) return;
  const margin = 16;
  const maxLeft = Math.max(margin, window.innerWidth - root.offsetWidth - margin);
  const maxTop = Math.max(margin, window.innerHeight - root.offsetHeight - margin);
  const left = Math.min(
    maxLeft,
    Math.max(margin, event.clientX - dragState.offsetX),
  );
  const top = Math.min(
    maxTop,
    Math.max(margin, event.clientY - dragState.offsetY),
  );
  root.style.left = `${left}px`;
  root.style.top = `${top}px`;
  root.style.right = "auto";
  root.style.bottom = "auto";
}

function endDrag(event) {
  const root = shadow?.querySelector(".tld-root");
  if (!root || !dragState || event.pointerId !== dragState.pointerId) return;
  root.classList.remove("tld-dragging");
  root.releasePointerCapture?.(event.pointerId);
  dragState = undefined;
}

function render(message, summary = false) {
  const root = shadow.querySelector(".tld-root");
  root.classList.remove("tld-hidden");
  root.innerHTML = `
    <header class="tld-header">
      <div class="tld-brand">
        <img class="tld-brand-mark" src="${ASSET("WebhoundW.png")}" width="28" height="28" alt="">
        <strong>WebHound</strong>
      </div>
      <div class="tld-actions">
        <button class="tld-action" type="button" data-refresh aria-label="Refresh summary">↻</button>
        <button class="tld-action" type="button" data-settings aria-label="Settings">⚙</button>
        <button class="tld-action" type="button" data-close aria-label="Close">
          <img src="${ASSET("close.svg")}" width="13" height="13" alt="">
        </button>
      </div>
    </header>
    <aside class="tld-settings" aria-label="Settings">
      <h2>Settings</h2>
      <label for="tld-api-key">API key</label>
      <input id="tld-api-key" type="password" data-api-key autocomplete="off" spellcheck="false">
      <label for="tld-model">AI model</label>
      <select id="tld-model" data-model>
        ${Object.entries(MODEL_GROUPS).map(([provider, models]) => `
          <optgroup label="${provider}" data-provider="${provider}">
            ${models.map((model) => `<option value="${model}">${model}</option>`).join("")}
          </optgroup>
        `).join("")}
      </select>
      <label class="tld-setting-check">
        <input type="checkbox" data-auto-show>
        Show summaries automatically
      </label>
      <label for="tld-theme">Theme</label>
      <select id="tld-theme" data-theme>
        <option value="system">System default</option>
        <option value="light">Light</option>
        <option value="dark">Dark</option>
      </select>
    </aside>
    <main class="tld-body${summary ? " tld-ready" : ""}">${message}</main>
  `;
  syncSettingsMenu(root);
}

function extractPage() {
  const root =
    document.querySelector("article") ||
    document.querySelector("[role='main']") ||
    document.querySelector("main") ||
    document.body;
  const usedIds = new Set([...document.querySelectorAll("[id]")].map((element) => element.id));
  const headingIds = new Set();
  const headings = [...root.querySelectorAll("h1, h2, h3")].map((element, index) => {
    if (!element.id || headingIds.has(element.id)) {
      let nextId = `tld-section-${index}`;
      let suffix = 1;
      while (usedIds.has(nextId)) nextId = `tld-section-${index}-${suffix++}`;
      element.id = nextId;
    }
    usedIds.add(element.id);
    headingIds.add(element.id);
    return { id: element.id, text: element.innerText.trim().slice(0, 120) };
  }).filter((heading) => heading.text);
  const clone = root.cloneNode(true);
  clone.querySelectorAll("script, style, noscript, nav, footer, aside, iframe, svg, form")
    .forEach((element) => element.remove());
  const text = clone.innerText.replace(/\s+/g, " ").trim().slice(0, 9000);
  return {
    title: document.title || "Untitled page",
    headings,
    text,
  };
}

function summaryHtml(summary, validIds, deduplicateLocations = true, maxItems = Infinity) {
  const usedIds = new Set();
  return (Array.isArray(summary) ? summary : [])
    .filter((part) => {
      if (!part?.text || !part.headingId || !validIds.has(part.headingId)) {
        return false;
      }
      if (deduplicateLocations && usedIds.has(part.headingId)) return false;
      usedIds.add(part.headingId);
      return true;
    })
    .slice(0, maxItems)
    .map((part) => {
      const jump = part.headingId ? ` data-jump="${escapeHtml(part.headingId)}"` : "";
      return `<span class="tld-summary-sentence"${jump}>${escapeHtml(part.text)}</span>`;
    })
    .join(" ");
}

function renderSummary(result, page) {
  const validIds = new Set(page.headings.map((heading) => heading.id));
  const summaryCount = Math.min(6, Math.max(2, Math.ceil(page.text.length / 1200)));
  const points = (result.keyPoints || []).slice(0, 3).map((point) =>
    `<li><img src="${ASSET("status-dot.svg")}" width="5" height="5" alt="">${escapeHtml(point)}</li>`,
  ).join("");
  render(`
    <section class="tld-section">
      <h2>Summary</h2>
      <p class="tld-summary">${summaryHtml(result.summary, validIds, true, summaryCount)}</p>
    </section>
    ${points ? `
      <section class="tld-section">
        <h2>Key points</h2>
        <ul class="tld-points">${points}</ul>
      </section>` : ""}
  `, true);
}

async function analyze(force = false) {
  if (analyzing) return;
  manuallyHidden = false;
  const { autoShow = true } = await chrome.storage.sync.get("autoShow");
  if (!force && !autoShow) return;
  const page = extractPage();
  currentPage = page;
  if (page.text.length < 80) return;
  analyzing = true;
  ensureUi();
  render("<p class='tld-message'>Summarizing…</p>");
  try {
    const response = await chrome.runtime.sendMessage({
      type: "TLD_ANALYZE",
      payload: { page },
    });
    if (!response?.ok) throw new Error(response?.error || "Analysis failed");
    currentResult = response.result;
    if (!manuallyHidden) renderSummary(currentResult, page);
  } catch (error) {
    if (!manuallyHidden) render(`<p class="tld-message">${escapeHtml(error.message)}</p>`);
  } finally {
    analyzing = false;
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", analyze, { once: true });
} else {
  analyze();
}
